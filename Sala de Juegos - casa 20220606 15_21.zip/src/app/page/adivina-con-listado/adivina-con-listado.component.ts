import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adivina-con-listado',
  templateUrl: './adivina-con-listado.component.html',
  styleUrls: ['./adivina-con-listado.component.css']
})
export class AdivinaConListadoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
