import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listado-resultados',
  templateUrl: './listado-resultados.component.html',
  styleUrls: ['./listado-resultados.component.css']
})
export class ListadoResultadosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
