import { UsuarioPPT } from './usuario-ppt';

describe('UsuarioPPT', () => {
  it('should create an instance', () => {
    expect(new UsuarioPPT()).toBeTruthy();
  });
});
