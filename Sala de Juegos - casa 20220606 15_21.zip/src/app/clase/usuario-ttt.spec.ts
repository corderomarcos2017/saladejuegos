import { UsuarioTTT } from './usuario-ttt';

describe('UsuarioTTT', () => {
  it('should create an instance', () => {
    expect(new UsuarioTTT()).toBeTruthy();
  });
});
